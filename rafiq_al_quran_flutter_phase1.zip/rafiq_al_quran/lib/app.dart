import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';

import 'core/constants/app_constants.dart';
import 'core/theme/app_theme.dart';
import 'screens/home/home_screen.dart';

/// جذر التطبيق — يضبط اللغة العربية واتجاه RTL والثيم المستمد من
/// الهوية البصرية الأصلية، ثم يعرض الشاشة الرئيسية.
///
/// الاتجاه يعتمد تلقائيًا على اللغة العربية (locale: ar) دون تكرار
/// إعدادات Directionality يدويًا — كما أوصت إرشادات المشروع.
library;

class RafiqApp extends StatelessWidget {
  const RafiqApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: AppConstants.appNameAr,
      debugShowCheckedModeBanner: false,

      // اللغة العربية افتراضيًا — كما في النسخة الأصلية (dir="rtl")
      locale: const Locale('ar'),
      supportedLocales: const [
        Locale('ar'),
        Locale('en'),
      ],
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],

      theme: AppTheme.light(),

      // المرحلة الأولى: شاشة واحدة رئيسية.
      // سيُستبدل بنظام مسارات منظم في core/routing/ عند بناء بقية الشاشات.
      home: const HomeScreen(),
    );
  }
}
