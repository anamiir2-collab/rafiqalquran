/// ثوابت التطبيق — قيم مستمدة من المشروع الأصلي (PWA)
/// المصدر: index.html + manifest.json + js/storage.js + js/audio.js
library;

class AppConstants {
  AppConstants._();

  /// اسم التطبيق الظاهر للمستخدم
  static const String appNameAr = 'رفيق القرآن للأطفال';

  /// الاسم التقني بالإنجليزية
  static const String appNameEn = 'Rafiq Al-Quran';

  /// الشعار الظاهر في أسفل الشاشة الرئيسية (كما في js/app.js)
  static const String tagline = 'رفيق القرآن — رفيقك في رحلة القرآن';

  /// مفتاح الحالة في التخزين المحلي — مطابق تمامًا لمفتاح النسخة الأصلية
  /// في js/storage.js ليظل التوافق المستقبلي (تصدير/استيراد) ممكنًا.
  static const String storageStateKey = 'rafiq_state_v1';

  /// إصدار مخطط الحالة (v: 1 في js/storage.js)
  static const int stateVersion = 1;

  /// القرّاء المتاحون في everyayah.com كما وردت في js/audio.js
  /// (سيُستخدم في المرحلة الثالثة: رحلة الحفظ)
  static const Map<String, String> reciters = {
    'Alafasy_128kbps': 'مشاري العفاسي',
    'Husary_128kbps': 'محمود خليل الحصري',
    'Minshawy_Murattal_128kbps': 'محمد صديق المنشاوي',
  };

  /// القارئ الافتراضي كما في إعدادات النسخة الأصلية
  static const String defaultReciter = 'Minshawy_Murattal_128kbps';

  /// نمط رابط تلاوة الآية الواحدة على everyayah.com (من js/audio.js):
  /// https://everyayah.com/data/{reciter}/SSSAAA.mp3
  /// حيث SSS رقم السورة بثلاث خانات و AAA رقم الآية بثلاث خانات.
  static String ayahAudioUrl(String reciter, int surah, int ayah) {
    final s = surah.toString().padLeft(3, '0');
    final a = ayah.toString().padLeft(3, '0');
    return 'https://everyayah.com/data/$reciter/$s$a.mp3';
  }
}
