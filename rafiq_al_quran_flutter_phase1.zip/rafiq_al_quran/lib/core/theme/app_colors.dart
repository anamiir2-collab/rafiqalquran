/// الهوية اللونية للتطبيق — منقولة حرفيًا من متغيرات CSS في
/// `css/style.css` (التصميم الحالي للنسخة الأصلية: بنفسجي/نعناعي/مرجاني/
/// أصفر/سماوي مع ذهبي للمكافآت) — وليست اختراعًا جديدًا.
library;

import 'package:flutter/material.dart';

abstract final class AppColors {
  // ===== البنفسجي الأساسي — لون التطبيق الرئيسي =====
  static const Color primary = Color(0xFF5B45D9);
  static const Color primaryDark = Color(0xFF4731B8);
  static const Color primaryDeep = Color(0xFF352296);
  static const Color primaryLight = Color(0xFFECE8FB);
  static const Color primarySoft = Color(0xFFF5F3FE);
  static const Color purple = Color(0xFF8B6DE8);
  static const Color purpleLight = Color(0xFFEFE9FC);

  // ===== الألوان الباستيل (Pastel Accents) =====
  static const Color mint = Color(0xFF62D6A3);
  static const Color mintLight = Color(0xFFDCF7EC);
  static const Color yellow = Color(0xFFFFD86B);
  static const Color yellowLight = Color(0xFFFFF3CC);
  static const Color coral = Color(0xFFF58F8F);
  static const Color coralLight = Color(0xFFFDE2E2);
  static const Color sky = Color(0xFF9DDCF2);
  static const Color skyLight = Color(0xFFE4F4FB);

  // ===== الخلفيات =====
  static const Color background = Color(0xFFFAF9FF);
  static const Color white = Color(0xFFFFFFFF);
  static const Color beige = Color(0xFFEFE9F8);

  // ===== النصوص =====
  static const Color text = Color(0xFF252044);
  static const Color textSoft = Color(0xFF77738A);
  static const Color textFaint = Color(0xFFA8A4B8);
  static const Color line = Color(0xFFECE8F5);

  // ===== حالات النجاح/التحذير/الخطأ =====
  static const Color success = Color(0xFF5CCB91);
  static const Color warning = Color(0xFFF5C85B);
  static const Color danger = Color(0xFFE87979);

  // ===== الذهبي (للمكافآت والنجوم) =====
  static const Color gold = Color(0xFFA88445);
  static const Color goldDeep = Color(0xFF8A6A2E);
  static const Color goldLight = Color(0xFFF5E8C9);

  // ===== المصحف =====
  static const Color quranBg = Color(0xFFF7F1E5);
  static const Color quranPage = Color(0xFFFFFDF7);
  static const Color quranText = Color(0xFF171717);
  static const Color quranGold = Color(0xFFA88445);
  static const Color quranBorder = Color(0xFFD9C7A0);

  /// تدرّج البطل الرئيسي — مطابق لـ --grad-hero في CSS الأصلي
  static const LinearGradient heroGradient = LinearGradient(
    begin: Alignment.topRight,
    end: Alignment.bottomLeft,
    colors: [purple, primary, primaryDeep],
  );

  /// تدرّج النجوم/المكافآت — مطابق لـ --grad-gold
  static const LinearGradient goldGradient = LinearGradient(
    begin: Alignment.topRight,
    end: Alignment.bottomLeft,
    colors: [yellow, Color(0xFFF5C85B), Color(0xFFE6A93E)],
  );
}
