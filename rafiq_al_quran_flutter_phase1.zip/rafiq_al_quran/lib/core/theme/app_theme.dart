import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'app_colors.dart';

/// ثيم التطبيق — يعكس نظام التصميم في `css/style.css` للنسخة الأصلية:
/// خط Tajawal للواجهة، زوايا دائرية ناعمة (20-24px)، ظلال بنفسجية خفيفة.
library;

abstract final class AppTheme {
  /// عائلة خط الواجهة (Tajawal محوّل من أصول المشروع الأصلي)
  static const String uiFont = 'Tajawal';

  /// خط النص القرآني (Amiri Quran من أصول المشروع الأصلي)
  static const String quranFont = 'AmiriQuran';

  /// خط Amiri للنصوص الطويلة/الاقتباسات
  static const String serifFont = 'Amiri';

  static ThemeData light() {
    const colorScheme = ColorScheme.light(
      primary: AppColors.primary,
      onPrimary: AppColors.white,
      secondary: AppColors.mint,
      onSecondary: AppColors.text,
      tertiary: AppColors.gold,
      surface: AppColors.white,
      onSurface: AppColors.text,
      error: AppColors.danger,
    );

    final base = ThemeData(
      useMaterial3: true,
      colorScheme: colorScheme,
      scaffoldBackgroundColor: AppColors.background,
      fontFamily: uiFont,
    );

    return base.copyWith(
      textTheme: _textTheme(base.textTheme),

      appBarTheme: const AppBarTheme(
        backgroundColor: AppColors.background,
        foregroundColor: AppColors.text,
        elevation: 0,
        scrolledUnderElevation: 0,
        centerTitle: true,
        systemOverlayStyle: SystemUiOverlayStyle(
          statusBarColor: Colors.transparent,
          statusBarIconBrightness: Brightness.dark,
        ),
      ),

      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: AppColors.primary,
          foregroundColor: AppColors.white,
          elevation: 0,
          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 14),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
          textStyle: const TextStyle(
            fontFamily: uiFont,
            fontSize: 16,
            fontWeight: FontWeight.w700,
          ),
        ),
      ),

      filledButtonTheme: FilledButtonThemeData(
        style: FilledButton.styleFrom(
          backgroundColor: AppColors.primary,
          foregroundColor: AppColors.white,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
        ),
      ),

      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: AppColors.primarySoft,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: BorderSide.none,
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: const BorderSide(color: AppColors.primary, width: 1.5),
        ),
        contentPadding:
            const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      ),

      snackBarTheme: SnackBarThemeData(
        backgroundColor: AppColors.text,
        contentTextStyle: const TextStyle(
          fontFamily: uiFont,
          color: AppColors.white,
          fontSize: 14,
        ),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
        ),
      ),

      dividerTheme: const DividerThemeData(color: AppColors.line, thickness: 1),
    );
  }

  /// أحجام النصوص — قريبة من مقاسات CSS الأصلية (h1/h2/body/small/tiny)
  static TextTheme _textTheme(TextTheme base) {
    return base.copyWith(
      headlineMedium: const TextStyle(
        fontSize: 24,
        fontWeight: FontWeight.w800,
        color: AppColors.text,
        height: 1.3,
      ),
      titleLarge: const TextStyle(
        fontSize: 18,
        fontWeight: FontWeight.w700,
        color: AppColors.text,
      ),
      titleMedium: const TextStyle(
        fontSize: 16,
        fontWeight: FontWeight.w700,
        color: AppColors.text,
      ),
      bodyLarge: const TextStyle(
        fontSize: 16,
        color: AppColors.text,
        height: 1.6,
      ),
      bodyMedium: const TextStyle(
        fontSize: 14,
        color: AppColors.text,
        height: 1.6,
      ),
      bodySmall: const TextStyle(
        fontSize: 13,
        color: AppColors.textSoft,
        height: 1.5,
      ),
      labelSmall: const TextStyle(
        fontSize: 11,
        color: AppColors.textFaint,
        height: 1.4,
      ),
    );
  }
}
