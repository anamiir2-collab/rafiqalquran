/// أدوات الأرقام العربية — مكافئ لدالة App.arDigits في js/app.js
/// لعرض الأرقام بالصيغة العربية المشرقية (٠١٢٣...) كما في الواجهة الأصلية.
library;

/// الأرقام العربية المشرقية بالترتيب
const List<String> _arabicDigits = [
  '٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩',
];

/// يحوّل كل الأرقام اللاتينية (0-9) داخل النص إلى أرقام عربية (٠-٩).
/// يُبقي باقي الحروف كما هي، لذا يمكن تمرير نص مختلط بأمان.
String toArabicDigits(String input) {
  final buffer = StringBuffer();
  for (final codeUnit in input.codeUnits) {
    if (codeUnit >= 0x30 && codeUnit <= 0x39) {
      // ASCII '0'..'9'
      buffer.write(_arabicDigits[codeUnit - 0x30]);
    } else {
      buffer.writeCharCode(codeUnit);
    }
  }
  return buffer.toString();
}

/// ينسّق عددًا صحيحًا بأرقام عربية، مع فصل الآلاف بفاصلة عربية اختياريًا.
String arNum(int number, {bool groupThousands = false}) {
  var text = number.toString();
  if (groupThousands) {
    final buffer = StringBuffer();
    for (var i = 0; i < text.length; i++) {
      final remaining = text.length - i;
      buffer.write(text[i]);
      if (remaining > 1 && remaining % 3 == 1) buffer.write('،');
    }
    text = buffer.toString();
  }
  return toArabicDigits(text);
}
