import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'app.dart';
import 'providers/progress_provider.dart';
import 'providers/user_provider.dart';
import 'services/storage_service.dart';

/// نقطة انطلاق التطبيق — المرحلة الأولى من التحويل إلى Flutter.
///
/// التسلسل:
/// 1. تهيئة الربط قبل أي استدعاء منصات (shared_preferences).
/// 2. تحميل الحالة المحلية بمخطط rafiq_state_v1 (نفس مخطط النسخة الأصلية).
/// 3. توفير المزودين عبر MultiProvider.
/// 4. تشغيل RafiqApp (عربي + RTL + ثيم الهوية الأصلية).
library;

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  final storage = StorageService();
  await storage.load();

  runApp(
    MultiProvider(
      providers: [
        Provider<StorageService>.value(value: storage),
        ChangeNotifierProvider<UserProvider>(
          create: (_) => UserProvider(storage),
        ),
        ChangeNotifierProvider<ProgressProvider>(
          create: (_) => ProgressProvider(storage),
        ),
      ],
      child: const RafiqApp(),
    ),
  );
}
