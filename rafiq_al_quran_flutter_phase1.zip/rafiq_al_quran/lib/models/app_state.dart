import 'dart:convert';

import '../core/constants/app_constants.dart';

/// نماذج حالة التطبيق — مطابقة تمامًا لمخطط `rafiq_state_v1` في
/// js/storage.js من المشروع الأصلي (نفس الحقول ونفس الأسماء ونفس القيم
/// الافتراضية) لضمان التوافق المستقبلي عند التصدير/الاستيراد أو الترحيل.
///
/// ملاحظة المرحلة الأولى: يُنفَّذ هنا الجزء الذي تحتاجه الشاشة الرئيسية
/// (الملف الشخصي، الإعدادات، المكافآت، الإحصاءات، تقدم السور) مع إبقاء
/// الحقول الأخرى في المخطط كحقول محفوظة كما هي حتى تُستخدم في مراحل لاحقة.
library;

/* ================== الملف الشخصي ================== */

class AppProfile {
  final String name;
  final String avatar;
  final bool onboarded;

  const AppProfile({
    this.name = '',
    this.avatar = 'falcon',
    this.onboarded = false,
  });

  factory AppProfile.fromJson(Map<String, dynamic> json) {
    return AppProfile(
      name: _asString(json['name'], ''),
      avatar: _asString(json['avatar'], 'falcon'),
      onboarded: _asBool(json['onboarded'], false),
    );
  }

  Map<String, dynamic> toJson() => {
        'name': name,
        'avatar': avatar,
        'onboarded': onboarded,
      };

  AppProfile copyWith({String? name, String? avatar, bool? onboarded}) {
    return AppProfile(
      name: name ?? this.name,
      avatar: avatar ?? this.avatar,
      onboarded: onboarded ?? this.onboarded,
    );
  }
}

/* ================== الإعدادات ================== */

class AppSettings {
  final String reciter;
  final double speed;
  final int repeatCount;
  final String quranFontSize;
  final bool soundEffects;
  final bool uiSounds;
  final bool autoPlay;
  final String theme;
  final String memorizationDirection;

  const AppSettings({
    this.reciter = AppConstants.defaultReciter,
    this.speed = 1,
    this.repeatCount = 3,
    this.quranFontSize = 'md',
    this.soundEffects = true,
    this.uiSounds = true,
    this.autoPlay = true,
    this.theme = 'light',
    this.memorizationDirection = 'backward',
  });

  factory AppSettings.fromJson(Map<String, dynamic> json) {
    const fallback = AppSettings();
    return AppSettings(
      reciter: _asString(json['reciter'], fallback.reciter),
      speed: _asDouble(json['speed'], fallback.speed),
      repeatCount: _asInt(json['repeatCount'], fallback.repeatCount),
      quranFontSize: _asString(json['quranFontSize'], fallback.quranFontSize),
      soundEffects: _asBool(json['soundEffects'], fallback.soundEffects),
      uiSounds: _asBool(json['uiSounds'], fallback.uiSounds),
      autoPlay: _asBool(json['autoPlay'], fallback.autoPlay),
      theme: _asString(json['theme'], fallback.theme),
      memorizationDirection:
          _asString(json['memorizationDirection'], fallback.memorizationDirection),
    );
  }

  Map<String, dynamic> toJson() => {
        'reciter': reciter,
        'speed': speed,
        'repeatCount': repeatCount,
        'quranFontSize': quranFontSize,
        'soundEffects': soundEffects,
        'uiSounds': uiSounds,
        'autoPlay': autoPlay,
        'theme': theme,
        'memorizationDirection': memorizationDirection,
      };
}

/* ================== تقدم السورة ================== */

/// حالة السورة — نفس شكل SurahProg في js/storage.js:
/// status: "new" | "learning" | "mastered"
class SurahProgress {
  final String status;
  final List<int> memorized;
  final int mastery; // 0..100
  final int interval; // أيام — نظام التكرار المتباعد
  final String? nextReview; // YYYY-MM-DD
  final int? lastReview; // timestamp
  final int reviewCount;
  final int? completedAt; // timestamp

  const SurahProgress({
    this.status = 'learning',
    this.memorized = const [],
    this.mastery = 0,
    this.interval = 1,
    this.nextReview,
    this.lastReview,
    this.reviewCount = 0,
    this.completedAt,
  });

  bool get isMastered => status == 'mastered';

  factory SurahProgress.fromJson(Map<String, dynamic> json) {
    return SurahProgress(
      status: _asString(json['status'], 'learning'),
      memorized: _asIntList(json['memorized']),
      mastery: _asInt(json['mastery'], 0).clamp(0, 100).toInt(),
      interval: _asInt(json['interval'], 1),
      nextReview: json['nextReview'] is String
          ? json['nextReview'] as String
          : null,
      lastReview: _asNullableInt(json['lastReview']),
      reviewCount: _asInt(json['reviewCount'], 0),
      completedAt: _asNullableInt(json['completedAt']),
    );
  }

  Map<String, dynamic> toJson() => {
        'status': status,
        'memorized': memorized,
        'mastery': mastery,
        'interval': interval,
        'nextReview': nextReview,
        'lastReview': lastReview,
        'reviewCount': reviewCount,
        'completedAt': completedAt,
      };
}

/* ================== المكافآت ================== */

class RewardAchievement {
  final String id;
  final int ts;

  const RewardAchievement({required this.id, required this.ts});

  factory RewardAchievement.fromJson(Map<String, dynamic> json) {
    return RewardAchievement(
      id: _asString(json['id'], ''),
      ts: _asInt(json['ts'], 0),
    );
  }

  Map<String, dynamic> toJson() => {'id': id, 'ts': ts};
}

class RewardsState {
  final int stars;
  final int points;
  final List<String> badges;
  final List<RewardAchievement> achievements;

  const RewardsState({
    this.stars = 0,
    this.points = 0,
    this.badges = const [],
    this.achievements = const [],
  });

  factory RewardsState.fromJson(Map<String, dynamic> json) {
    return RewardsState(
      stars: _asInt(json['stars'], 0),
      points: _asInt(json['points'], 0),
      badges: _asStringList(json['badges']),
      achievements: _asList(json['achievements'])
          .whereType<Map<String, dynamic>>()
          .map(RewardAchievement.fromJson)
          .toList(),
    );
  }

  Map<String, dynamic> toJson() => {
        'stars': stars,
        'points': points,
        'badges': badges,
        'achievements': achievements.map((a) => a.toJson()).toList(),
      };
}

/* ================== الإحصاءات ================== */

class StatsState {
  final int learningSeconds;
  final Map<String, int> dailySeconds; // {"YYYY-MM-DD": ثوانٍ}
  final List<String> activeDays; // ["YYYY-MM-DD"]
  final int quizCorrect;
  final int quizWrong;
  final int recordings;
  final int reviewsDone;
  final List<String> storiesRead;
  final List<String> moralsDone;

  const StatsState({
    this.learningSeconds = 0,
    this.dailySeconds = const {},
    this.activeDays = const [],
    this.quizCorrect = 0,
    this.quizWrong = 0,
    this.recordings = 0,
    this.reviewsDone = 0,
    this.storiesRead = const [],
    this.moralsDone = const [],
  });

  factory StatsState.fromJson(Map<String, dynamic> json) {
    final daily = <String, int>{};
    if (json['dailySeconds'] is Map) {
      (json['dailySeconds'] as Map).forEach((k, v) {
        final value = _asNullableInt(v);
        if (k is String && value != null) daily[k] = value;
      });
    }
    return StatsState(
      learningSeconds: _asInt(json['learningSeconds'], 0),
      dailySeconds: daily,
      activeDays: _asStringList(json['activeDays']),
      quizCorrect: _asInt(json['quizCorrect'], 0),
      quizWrong: _asInt(json['quizWrong'], 0),
      recordings: _asInt(json['recordings'], 0),
      reviewsDone: _asInt(json['reviewsDone'], 0),
      storiesRead: _asStringList(json['storiesRead']),
      moralsDone: _asStringList(json['moralsDone']),
    );
  }

  Map<String, dynamic> toJson() => {
        'learningSeconds': learningSeconds,
        'dailySeconds': dailySeconds,
        'activeDays': activeDays,
        'quizCorrect': quizCorrect,
        'quizWrong': quizWrong,
        'recordings': recordings,
        'reviewsDone': reviewsDone,
        'storiesRead': storiesRead,
        'moralsDone': moralsDone,
      };
}

/* ================== آخر موضع ================== */

class LastAyah {
  final int s; // رقم السورة
  final int a; // رقم الآية

  const LastAyah({this.s = 112, this.a = 1});

  factory LastAyah.fromJson(Map<String, dynamic> json) => LastAyah(
        s: _asInt(json['s'], 112),
        a: _asInt(json['a'], 1),
      );

  Map<String, dynamic> toJson() => {'s': s, 'a': a};
}

/* ================== الحالة الكلية ================== */

class AppState {
  final int v;
  final int createdAt;
  final AppProfile profile;
  final AppSettings settings;

  /// تقدم السور: المفتاح رقم السورة كنص (مطابق للنسخة الأصلية)
  final Map<String, SurahProgress> progress;

  final RewardsState rewards;
  final StatsState stats;
  final LastAyah lastAyah;

  const AppState({
    this.v = AppConstants.stateVersion,
    required this.createdAt,
    this.profile = const AppProfile(),
    this.settings = const AppSettings(),
    this.progress = const {},
    this.rewards = const RewardsState(),
    this.stats = const StatsState(),
    this.lastAyah = const LastAyah(),
  });

  /// الحالة الافتراضية — مطابقة لدالة defaults() في js/storage.js
  factory AppState.defaults() =>
      AppState(createdAt: DateTime.now().millisecondsSinceEpoch);

  /// تحليل آمن: أي حقل مفقود أو غير صالح يعود لقيمته الافتراضية
  /// (نفس منطق Object.assign(defaults(), parsed) في النسخة الأصلية).
  factory AppState.fromJson(Map<String, dynamic> json) {
    final progress = <String, SurahProgress>{};
    if (json['progress'] is Map) {
      (json['progress'] as Map).forEach((k, v) {
        if (k is String && v is Map<String, dynamic>) {
          progress[k] = SurahProgress.fromJson(v);
        }
      });
    }
    return AppState(
      v: _asInt(json['v'], AppConstants.stateVersion),
      createdAt: _asInt(json['createdAt'], DateTime.now().millisecondsSinceEpoch),
      profile: json['profile'] is Map<String, dynamic>
          ? AppProfile.fromJson(json['profile'] as Map<String, dynamic>)
          : const AppProfile(),
      settings: json['settings'] is Map<String, dynamic>
          ? AppSettings.fromJson(json['settings'] as Map<String, dynamic>)
          : const AppSettings(),
      progress: progress,
      rewards: json['rewards'] is Map<String, dynamic>
          ? RewardsState.fromJson(json['rewards'] as Map<String, dynamic>)
          : const RewardsState(),
      stats: json['stats'] is Map<String, dynamic>
          ? StatsState.fromJson(json['stats'] as Map<String, dynamic>)
          : const StatsState(),
      lastAyah: json['lastAyah'] is Map<String, dynamic>
          ? LastAyah.fromJson(json['lastAyah'] as Map<String, dynamic>)
          : const LastAyah(),
    );
  }

  /// يفك سلسلة JSON إلى حالة؛ يُعيد الافتراضية عند أي فشل
  /// (مطابق لسلوك try/catch في storage.load الأصلي).
  factory AppState.fromJsonString(String raw) {
    try {
      final decoded = jsonDecode(raw);
      if (decoded is Map<String, dynamic> && decoded['progress'] is Map) {
        return AppState.fromJson(decoded);
      }
      return AppState.defaults();
    } on FormatException {
      return AppState.defaults();
    } catch (_) {
      return AppState.defaults();
    }
  }

  Map<String, dynamic> toJson() => {
        'v': v,
        'createdAt': createdAt,
        'profile': profile.toJson(),
        'settings': settings.toJson(),
        'progress': progress.map((k, v) => MapEntry(k, v.toJson())),
        'rewards': rewards.toJson(),
        'stats': stats.toJson(),
        'lastAyah': lastAyah.toJson(),
      };

  String toJsonString() => jsonEncode(toJson());

  AppState copyWith({
    AppProfile? profile,
    AppSettings? settings,
    Map<String, SurahProgress>? progress,
    RewardsState? rewards,
    StatsState? stats,
    LastAyah? lastAyah,
  }) {
    return AppState(
      v: v,
      createdAt: createdAt,
      profile: profile ?? this.profile,
      settings: settings ?? this.settings,
      progress: progress ?? this.progress,
      rewards: rewards ?? this.rewards,
      stats: stats ?? this.stats,
      lastAyah: lastAyah ?? this.lastAyah,
    );
  }

  /* ------- دوال مشتقة — مطابقة لدول storage.js ------- */

  /// عدد الآيات المحفوظة (countMemorizedAyahs)
  int get memorizedAyahsCount => progress.values
      .fold(0, (sum, p) => sum + p.memorized.length);

  /// عدد السور المتقنة (countMasteredSurahs)
  int get masteredSurahsCount =>
      progress.values.where((p) => p.isMastered).length;

  /// عدد السور التي فيها تقدم (بدأت ولكن لم تكتمل)
  int get inProgressSurahsCount =>
      progress.values.where((p) => p.memorized.isNotEmpty && !p.isMastered).length;
}

/* ================== المستويات — من js/rewards.js ================== */

class RewardLevel {
  final int level;
  final int minPoints;
  final String title;

  const RewardLevel(this.level, this.minPoints, this.title);
}

/// نفس عتبات LEVELS في js/rewards.js
const List<RewardLevel> kRewardLevels = [
  RewardLevel(1, 0, 'مبتدئ مجتهد'),
  RewardLevel(2, 100, 'صاعد نحو الخير'),
  RewardLevel(3, 250, 'متقن صغير'),
  RewardLevel(4, 450, 'بطل الترديد'),
  RewardLevel(5, 700, 'نجم المراجعة'),
  RewardLevel(6, 1000, 'حافظ صغير'),
  RewardLevel(7, 1400, 'قائد الأبطال'),
];

class LevelInfo {
  final int level;
  final String title;
  final RewardLevel? next;
  final int progressPercent; // 0..100

  const LevelInfo({
    required this.level,
    required this.title,
    this.next,
    required this.progressPercent,
  });
}

/// مكافئ لدالة levelInfo(points) في js/rewards.js
LevelInfo levelInfoFor(int points) {
  var current = kRewardLevels.first;
  for (final l in kRewardLevels) {
    if (points >= l.minPoints) current = l;
  }
  RewardLevel? next;
  for (final l in kRewardLevels) {
    if (l.minPoints > current.minPoints) {
      next = l;
      break;
    }
  }
  final span = next != null ? next.minPoints - current.minPoints : 1;
  final progress = next != null
      ? ((points - current.minPoints) / span * 100).clamp(0, 100).round()
      : 100;
  return LevelInfo(
    level: current.level,
    title: current.title,
    next: next,
    progressPercent: progress,
  );
}

/* ================== أدوات تحليل متسامحة ================== */

int _asInt(dynamic v, int fallback) =>
    v is int ? v : (v is num ? v.round() : fallback);

int? _asNullableInt(dynamic v) =>
    v is int ? v : (v is num ? v.round() : null);

double _asDouble(dynamic v, double fallback) =>
    v is num ? v.toDouble() : fallback;

bool _asBool(dynamic v, bool fallback) => v is bool ? v : fallback;

String _asString(dynamic v, String fallback) =>
    v is String ? v : fallback;

List<dynamic> _asList(dynamic v) => v is List ? v : const [];

List<int> _asIntList(dynamic v) => _asList(v)
    .whereType<num>()
    .map((e) => e.round())
    .toList();

List<String> _asStringList(dynamic v) =>
    _asList(v).whereType<String>().toList();

/* ================== سلسلة الأيام المتواصلة ================== */

/// مكافئ لدالة streak() في js/storage.js — يحسب عدد الأيام المتتالية
/// حتى اليوم (أو حتى أمس إذا لم يسجل اليوم نشاطًا بعد).
int computeStreak(List<String> activeDays, DateTime today) {
  if (activeDays.isEmpty) return 0;
  final days = activeDays.toList()..sort();
  String key(DateTime d) =>
      '${d.year}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';

  final todayKey = key(today);
  final lastKey = days.last;
  final lastDate = DateTime.tryParse('${lastKey}T00:00:00');
  final todayDate = DateTime.tryParse('${todayKey}T00:00:00');
  if (lastDate == null || todayDate == null) return 0;

  final diff = todayDate.difference(lastDate).inDays;
  if (diff > 1) return 0;

  var count = 1;
  for (var i = days.length - 1; i > 0; i--) {
    final a = DateTime.tryParse('${days[i]}T00:00:00');
    final b = DateTime.tryParse('${days[i - 1]}T00:00:00');
    if (a == null || b == null) break;
    if (a.difference(b).inDays == 1) {
      count++;
    } else {
      break;
    }
  }
  return count;
}
