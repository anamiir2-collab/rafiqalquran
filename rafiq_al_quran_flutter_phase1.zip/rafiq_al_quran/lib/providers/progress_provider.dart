import 'package:flutter/foundation.dart';

import '../models/app_state.dart';
import '../services/storage_service.dart';

/// مزوّد التقدم — يعرض عدادات الإنجاز الحقيقية المستمدة من التخزين
/// المحلي (بدون أي بيانات وهمية).
///
/// مطابق لدوال storage.js المشتقة: countMemorizedAyahs،
/// countMasteredSurahs، streak، و rewards/levelInfo في rewards.js.
///
/// في المرحلة الأولى تكون جميع القيم صفرًا عند التشغيل الأول ثم تنمو
/// فعليًا مع تنفيذ منطق الحفظ والمراجعة في المراحل الثالثة والرابعة.
library;

class ProgressProvider extends ChangeNotifier {
  final StorageService _storage;

  ProgressProvider(this._storage);

  RewardsState get rewards => _storage.state.rewards;

  StatsState get stats => _storage.state.stats;

  /* ---------- العدادات الظاهرة في الشاشة الرئيسية ---------- */

  /// عدد النجوم (App.Storage.state.rewards.stars)
  int get stars => rewards.stars;

  /// عدد النقاط
  int get points => rewards.points;

  /// عدد الآيات المحفوظة فعليًا (countMemorizedAyahs)
  int get memorizedAyahs => _storage.state.memorizedAyahsCount;

  /// عدد السور قيد التقدم (بدأ فيها حفظ ولم تكتمل)
  int get surahsInProgress => _storage.state.inProgressSurahsCount;

  /// عدد السور المتقنة (countMasteredSurahs)
  int get surahsMastered => _storage.state.masteredSurahsCount;

  /// عدد الأيام المتواصلة (streak)
  int get streak => computeStreak(stats.activeDays, DateTime.now());

  /// إجمالي أيام النشاط (totalActiveDays)
  int get totalActiveDays => stats.activeDays.length;

  /// عدد مراجعات اليوم الحالي — يُستخدم في بطاقة «رحلتك اليوم»
  int get reviewsDone => stats.reviewsDone;

  /* ---------- المستوى (levelInfo من rewards.js) ---------- */

  LevelInfo get level => levelInfoFor(points);

  /* ---------- التحديث ---------- */

  /// إبلاغ المستمعين بعد أي كتابة تحدث في مكان آخر (خدمات المراحل القادمة)
  void refresh() => notifyListeners();
}
