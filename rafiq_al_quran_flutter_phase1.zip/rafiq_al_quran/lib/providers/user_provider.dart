import 'package:flutter/foundation.dart';

import '../models/app_state.dart';
import '../services/storage_service.dart';

/// مزوّد المستخدم — يكشف الملف الشخصي للطفل (الاسم، الأفاتار، حالة
/// الترحيب) ويحدّثه عبر StorageService.
///
/// في المرحلة الأولى يُستخدم لعرض تحية الشاشة الرئيسية وتعديل الاسم،
/// وسيُوسّع لاحقًا عند بناء شاشة الترحيب/الإعدادات الكاملة.
library;

class UserProvider extends ChangeNotifier {
  final StorageService _storage;

  UserProvider(this._storage);

  AppProfile get profile => _storage.state.profile;

  /// اسم الطفل — فارغ إذا لم يُدخل بعد
  String get name => profile.name;

  /// الأفاتار المختار (يُستخدم لاحقًا لرسم صورة الطفل كما في النسخة الأصلية)
  String get avatar => profile.avatar;

  bool get onboarded => profile.onboarded;

  /// حفظ اسم الطفل — يُقتطع من الفراغات ويُحدّد حدًا أقصى 30 حرفًا.
  Future<void> setName(String newName) async {
    final trimmed = newName.trim();
    if (trimmed == profile.name) return;
    final bounded =
        trimmed.length > 30 ? trimmed.substring(0, 30) : trimmed;
    await _storage.updateProfile(profile.copyWith(name: bounded));
    notifyListeners();
  }

  /// تحديد الترحيب كمكتمل (سيُستخدم في شاشة الترحيب لاحقًا)
  Future<void> completeOnboarding() async {
    if (profile.onboarded) return;
    await _storage.updateProfile(profile.copyWith(onboarded: true));
    notifyListeners();
  }
}
