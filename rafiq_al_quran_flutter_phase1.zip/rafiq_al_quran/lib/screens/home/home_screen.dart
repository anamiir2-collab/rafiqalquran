import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/constants/app_constants.dart';
import '../../core/theme/app_colors.dart';
import '../../core/utils/arabic_digits.dart';
import '../../providers/progress_provider.dart';
import '../../providers/user_provider.dart';
import '../../widgets/journey_today_card.dart';
import '../../widgets/quick_access_card.dart';
import '../../widgets/stat_counter_card.dart';
import '../../widgets/streak_strip.dart';

/// الشاشة الرئيسية — مكافئ pageHome في js/app.js.
///
/// تحية شخصية باسم الطفل + بطاقة «رحلتك اليوم» + شريط الالتزام +
/// عدادات حقيقية (نجوم/آيات محفوظة/سور قيد التقدم) + اختصارات الأقسام.
///
/// المرحلة الأولى: كل الأقسام الفرعية لم تُبنَ بعد، لذا تعرض الاختصارات
/// رسالة صادقة تُوضح مرحلة بنائها — بدون أي بيانات وهمية.
library;

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final user = context.watch<UserProvider>();
    final progress = context.watch<ProgressProvider>();

    final greetingName =
        user.name.isEmpty ? 'بطل' : user.name;

    return Scaffold(
      backgroundColor: AppColors.background,
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              _HomeHeader(greetingName: greetingName),
              const SizedBox(height: 14),
              JourneyTodayCard(
                onStartJourney: () => _showComingSoon(
                  context,
                  'رحلة الحفظ',
                  3,
                ),
              ),
              const SizedBox(height: 12),
              StreakStrip(
                streak: progress.streak,
                activeDays: progress.stats.activeDays,
              ),
              const SizedBox(height: 16),
              Row(
                children: [
                  Expanded(
                    child: StatCounterCard(
                      icon: Icons.star_rounded,
                      value: progress.stars,
                      label: 'نجمة',
                      iconColor: AppColors.goldDeep,
                      backgroundColor: AppColors.goldLight,
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: StatCounterCard(
                      icon: Icons.menu_book_rounded,
                      value: progress.memorizedAyahs,
                      label: 'آية محفوظة',
                      iconColor: AppColors.primary,
                      backgroundColor: AppColors.primaryLight,
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: StatCounterCard(
                      icon: Icons.flag_rounded,
                      value: progress.surahsInProgress,
                      label: 'سورة قيد التقدم',
                      iconColor: AppColors.mint,
                      backgroundColor: AppColors.mintLight,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 20),
              Row(
                children: [
                  Text('رحلة القرآن', style: theme.textTheme.titleLarge),
                  const Spacer(),
                  // المستوى الحالي — من نظام المكافآت الأصلي (rewards.js)
                  Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                    decoration: BoxDecoration(
                      color: AppColors.goldLight,
                      borderRadius: BorderRadius.circular(999),
                    ),
                    child: Text(
                      'المستوى ${arNum(progress.level.level)}: ${progress.level.title}',
                      style: const TextStyle(
                        fontSize: 11.5,
                        fontWeight: FontWeight.w700,
                        color: AppColors.goldDeep,
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              _QuickGrid(
                onSectionTap: _showComingSoon,
              ),
              const SizedBox(height: 20),
              Text(
                AppConstants.tagline,
                textAlign: TextAlign.center,
                style: theme.textTheme.labelSmall,
              ),
            ],
          ),
        ),
      ),
    );
  }

  /// رسالة صادقة: القسم لم يُبنَ بعد — يُنفذ في المرحلة المحددة من
  /// خطة التحويل. لا ادعاء أن القسم يعمل وهو لا يعمل.
  void _showComingSoon(BuildContext context, String sectionName, int phase) {
    final phaseNames = {
      2: 'البيانات والتخزين',
      3: 'القرآن والحفظ',
      4: 'بقية الأقسام',
      5: 'الجودة والإصدار',
    };
    ScaffoldMessenger.of(context).hideCurrentSnackBar();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          'قسم «$sectionName» سيُبنى في المرحلة ${arNum(phase)} '
          '(${phaseNames[phase] ?? ''}) من خطة التحويل',
        ),
        duration: const Duration(seconds: 3),
      ),
    );
  }
}

/* ================== رأس الشاشة ================== */

class _HomeHeader extends StatelessWidget {
  final String greetingName;

  const _HomeHeader({required this.greetingName});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final user = context.read<UserProvider>();

    return Row(
      children: [
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'السلام عليكم يا $greetingName',
                style: theme.textTheme.headlineMedium?.copyWith(fontSize: 21),
              ),
              const SizedBox(height: 2),
              Text(
                'جاهز تكمل رحلتك مع القرآن؟',
                style: theme.textTheme.bodySmall,
              ),
            ],
          ),
        ),
        IconButton(
          tooltip: 'تعديل اسمي',
          onPressed: () => _showNameDialog(context, user),
          icon: const Icon(Icons.tune_rounded, color: AppColors.textSoft),
        ),
        GestureDetector(
          onTap: () => _showNameDialog(context, user),
          child: Container(
            width: 44,
            height: 44,
            decoration: BoxDecoration(
              gradient: AppColors.heroGradient,
              shape: BoxShape.circle,
            ),
            child: const Icon(
              Icons.person_rounded,
              color: AppColors.white,
              size: 24,
            ),
          ),
        ),
      ],
    );
  }

  /// حوار تعديل اسم الطفل — وظيفة حقيقية تحفظ في التخزين المحلي
  /// وتُحدّث التحية فورًا (مكافئ إعداد الملف الشخصي في النسخة الأصلية).
  Future<void> _showNameDialog(BuildContext context, UserProvider user) {
    final controller = TextEditingController(text: user.name);
    return showDialog<void>(
      context: context,
      builder: (dialogContext) {
        return AlertDialog(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20),
          ),
          title: const Text('ما اسمك يا بطل؟'),
          content: TextField(
            controller: controller,
            autofocus: true,
            maxLength: 30,
            decoration: const InputDecoration(
              hintText: 'اكتب اسمك هنا (اختياري)',
              counterText: '',
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(dialogContext).pop(),
              child: const Text('إلغاء'),
            ),
            FilledButton(
              onPressed: () async {
                await user.setName(controller.text);
                if (dialogContext.mounted) {
                  Navigator.of(dialogContext).pop();
                }
              },
              child: const Text('حفظ'),
            ),
          ],
        );
      },
    );
  }
}

/* ================== شبكة الاختصارات ================== */

/// الاختصارات — كل قسم يظهر بصدق بمرحلته الحالية من خطة التحويل:
/// مدينة القرآن ورحلة الحفظ (المرحلة 3)، والبقية (المرحلة 4).
class _QuickGrid extends StatelessWidget {
  final void Function(BuildContext, String, int) onSectionTap;

  const _QuickGrid({required this.onSectionTap});

  @override
  Widget build(BuildContext context) {
    const sections = <({String title, String sub, IconData icon, int phase,
        Color bg, Color fg})>[
      (
        title: 'مدينة القرآن',
        sub: 'اقرأ واستمع',
        icon: Icons.menu_book_rounded,
        phase: 3,
        bg: AppColors.mintLight,
        fg: Color(0xFF1F7A55),
      ),
      (
        title: 'رحلة الحفظ',
        sub: 'احفظ آيات جديدة',
        icon: Icons.psychology_alt_rounded,
        phase: 3,
        bg: AppColors.primaryLight,
        fg: AppColors.primary,
      ),
      (
        title: 'وادي المراجعة',
        sub: 'ثبّت ما حفظت',
        icon: Icons.autorenew_rounded,
        phase: 4,
        bg: AppColors.skyLight,
        fg: Color(0xFF2A6E8C),
      ),
      (
        title: 'واحة القصص',
        sub: 'قصص قرآنية وأنبية',
        icon: Icons.auto_stories_rounded,
        phase: 4,
        bg: AppColors.coralLight,
        fg: Color(0xFFB25B5B),
      ),
      (
        title: 'حديقة الأخلاق',
        sub: 'تعلّم القيم',
        icon: Icons.eco_rounded,
        phase: 4,
        bg: AppColors.mintLight,
        fg: Color(0xFF1F7A55),
      ),
      (
        title: 'تحديات الإتقان',
        sub: 'ألعاب واختبارات',
        icon: Icons.emoji_events_rounded,
        phase: 4,
        bg: AppColors.goldLight,
        fg: AppColors.goldDeep,
      ),
      (
        title: 'المكافآت',
        sub: 'نجومك وأوسمتك',
        icon: Icons.stars_rounded,
        phase: 4,
        bg: AppColors.yellowLight,
        fg: AppColors.goldDeep,
      ),
      (
        title: 'لوحة ولي الأمر',
        sub: 'متابعة التقدم',
        icon: Icons.family_restroom_rounded,
        phase: 4,
        bg: AppColors.primaryLight,
        fg: AppColors.primaryDark,
      ),
    ];

    return LayoutBuilder(
      builder: (context, constraints) {
        final crossAxisCount = constraints.maxWidth >= 480 ? 4 : 2;
        return GridView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: crossAxisCount,
            mainAxisSpacing: 10,
            crossAxisSpacing: 10,
            // نسبة عالية بما يكفي للنص العربي بدون overflow
            childAspectRatio: crossAxisCount == 4 ? 0.95 : 1.18,
          ),
          itemCount: sections.length,
          itemBuilder: (context, i) {
            final s = sections[i];
            return QuickAccessCard(
              icon: s.icon,
              title: s.title,
              subtitle: s.sub,
              iconBackground: s.bg,
              iconColor: s.fg,
              onTap: () => onSectionTap(context, s.title, s.phase),
            );
          },
        );
      },
    );
  }
}
