import 'package:shared_preferences/shared_preferences.dart';

import '../core/constants/app_constants.dart';
import '../models/app_state.dart';

/// خدمة التخزين المحلي — البديل المباشر لطبقة `App.Storage` في js/storage.js.
///
/// مبدأ العمل مطابق للنسخة الأصلية: حالة واحدة (single state) بمخطط
/// `rafiq_state_v1` تُحفظ كسلسلة JSON واحدة، مع دمج آمن للحقول المفقودة
/// عند القراءة، وتحمّل كامل للبيانات الفاسدة (تعود للقيم الافتراضية).
///
/// ملاحظة أمان (كما في النسخة الأصلية): هذا التخزين غير مشفّر ومخصص
/// لإعدادات الطفل وتقدمه فقط — لا تُخزَّن فيه بيانات حساسة.
library;

class StorageService {
  SharedPreferences? _prefs;

  AppState _state = AppState.defaults();

  /// الحالة الحالية في الذاكرة
  AppState get state => _state;

  /// تهيئة الخدمة وتحميل الحالة من التخزين.
  /// تُستدعى مرة واحدة في main() قبل runApp.
  Future<AppState> load() async {
    _prefs ??= await SharedPreferences.getInstance();
    final raw = _prefs!.getString(AppConstants.storageStateKey);
    if (raw == null || raw.isEmpty) {
      _state = AppState.defaults();
    } else {
      _state = AppState.fromJsonString(raw);
    }
    return _state;
  }

  /// حفظ الحالة كاملة فورًا (مكافئ saveNow في النسخة الأصلية).
  Future<bool> save(AppState newState) async {
    _state = newState;
    _prefs ??= await SharedPreferences.getInstance();
    try {
      return await _prefs!
          .setString(AppConstants.storageStateKey, _state.toJsonString());
    } catch (_) {
      // التخزين ممتلئ أو غير متاح — لا نخفي المشكلة، لكن لا نُسقط التطبيق
      return false;
    }
  }

  /// تحديث الملف الشخصي وحفظ الحالة (مكافئ setProfile).
  Future<void> updateProfile(AppProfile profile) =>
      save(_state.copyWith(profile: profile));

  /// تحديث الإعدادات وحفظ الحالة (مكافئ setSetting/updateSettings).
  Future<void> updateSettings(AppSettings settings) =>
      save(_state.copyWith(settings: settings));

  /// حفظ آخر موضع وصل إليه الطفل (مكافئ setLastAyah).
  Future<void> setLastAyah(int surah, int ayah) =>
      save(_state.copyWith(lastAyah: LastAyah(s: surah, a: ayah)));

  /// مسح كل البيانات والعودة للحالة الافتراضية (مكافئ reset).
  Future<void> reset() async {
    _state = AppState.defaults();
    _prefs ??= await SharedPreferences.getInstance();
    await _prefs!.remove(AppConstants.storageStateKey);
  }
}
