import 'package:flutter/material.dart';

import '../core/theme/app_colors.dart';

/// بطاقة «رحلتك اليوم» — المكافئ المبسط لبطاقة الرحلة في js/app.js
/// (journey-card): هدف يومي + خطوات الرحلة الأربع كما في النسخة الأصلية
/// (استماع ← الترديد ← اختبار الإتقان ← المكافأة).
///
/// المرحلة الأولى: الهدف نصي مبدئي (بدون منطق تقدم حقيقي بعد)، والزر
/// يوضح بصدق أن رحلة الحفظ ستُبنى في المرحلة الثالثة. لا تُعرض إنجازات
/// وهمية.
library;

class JourneyTodayCard extends StatelessWidget {
  final VoidCallback onStartJourney;

  const JourneyTodayCard({super.key, required this.onStartJourney});

  static const List<({String label, IconData icon})> _steps = [
    (label: 'استماع', icon: Icons.headphones_outlined),
    (label: 'الترديد', icon: Icons.mic_none_outlined),
    (label: 'اختبار الإتقان', icon: Icons.psychology_outlined),
    (label: 'المكافأة', icon: Icons.emoji_events_outlined),
  ];

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Container(
      decoration: BoxDecoration(
        gradient: AppColors.heroGradient,
        borderRadius: BorderRadius.circular(24),
      ),
      padding: const EdgeInsets.fromLTRB(18, 18, 18, 18),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            children: [
              Container(
                width: 42,
                height: 42,
                decoration: BoxDecoration(
                  color: AppColors.white,
                  borderRadius: BorderRadius.circular(14),
                ),
                child: const Icon(
                  Icons.rocket_launch_outlined,
                  color: AppColors.primary,
                  size: 24,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'رحلتك اليوم',
                      style: theme.textTheme.titleLarge?.copyWith(
                        color: AppColors.white,
                        fontSize: 18,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      'هدف اليوم: احفظ آية جديدة وراجع ما حفظت',
                      style: theme.textTheme.bodySmall?.copyWith(
                        color: AppColors.white,
                        fontSize: 12.5,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              for (var i = 0; i < _steps.length; i++)
                _StepChip(
                  label: _steps[i].label,
                  icon: _steps[i].icon,
                  isLast: i == _steps.length - 1,
                ),
            ],
          ),
          const SizedBox(height: 16),
          SizedBox(
            height: 48,
            child: FilledButton(
              style: FilledButton.styleFrom(
                backgroundColor: AppColors.white,
                foregroundColor: AppColors.primary,
              ),
              onPressed: onStartJourney,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: const [
                  Text('ابدأ رحلتي', style: TextStyle(fontSize: 16)),
                  SizedBox(width: 6),
                  Icon(Icons.arrow_back_ios_new, size: 15),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _StepChip extends StatelessWidget {
  final String label;
  final IconData icon;
  final bool isLast;

  const _StepChip({
    required this.label,
    required this.icon,
    required this.isLast,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Column(
          children: [
            Container(
              width: 34,
              height: 34,
              decoration: BoxDecoration(
                color: AppColors.white.withAlpha(38),
                borderRadius: BorderRadius.circular(11),
              ),
              child: Icon(icon, color: AppColors.white, size: 19),
            ),
            const SizedBox(height: 5),
            Text(
              label,
              style: const TextStyle(
                color: AppColors.white,
                fontSize: 10.5,
                fontWeight: FontWeight.w500,
              ),
            ),
          ],
        ),
        if (!isLast)
          const Padding(
            padding: EdgeInsets.only(bottom: 18),
            child: Icon(
              Icons.chevron_left,
              color: AppColors.white,
              size: 16,
            ),
          ),
      ],
    );
  }
}
