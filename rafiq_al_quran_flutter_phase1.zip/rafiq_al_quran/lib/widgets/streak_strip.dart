import 'package:flutter/material.dart';

import '../core/theme/app_colors.dart';
import '../core/utils/arabic_digits.dart';

/// شريط الالتزام اليومي — مكافئ مبسط لبطاقة streak-hero-card في js/app.js:
/// شعلة + عدد الأيام المتواصلة + نقاط آخر 7 أيام (سبت..جمعة).
library;

class StreakStrip extends StatelessWidget {
  final int streak;
  final List<String> activeDays;

  const StreakStrip({
    super.key,
    required this.streak,
    required this.activeDays,
  });

  /// أسماء الأيام المختصرة كما في AR_DAYS_SHORT الأصلي
  /// (الأسبوع عندنا يبدأ السبت).
  static const List<String> _dayNames = [
    'سبت', 'أحد', 'إثن', 'ثلا', 'أرب', 'خمي', 'جمع',
  ];

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final today = DateTime.now();

    // في Dart: الإثنين=1 ... السبت=6، الأحد=7.
    // نريد فهرسًا عربيًا يبدأ بالسبت=0 → (weekday + 1) % 7
    final last7 = <({String name, bool active, bool isToday})>[];
    for (var i = 6; i >= 0; i--) {
      final day = today.subtract(Duration(days: i));
      final k =
          '${day.year}-${day.month.toString().padLeft(2, '0')}-${day.day.toString().padLeft(2, '0')}';
      final arabicIndex = (day.weekday + 1) % 7;
      last7.add((
        name: _dayNames[arabicIndex],
        active: activeDays.contains(k),
        isToday: i == 0,
      ));
    }

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      decoration: BoxDecoration(
        color: AppColors.primarySoft,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: AppColors.primaryLight),
      ),
      child: Row(
        children: [
          const Icon(
            Icons.local_fire_department,
            color: AppColors.coral,
            size: 30,
          ),
          const SizedBox(width: 10),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                arNum(streak),
                style: theme.textTheme.titleLarge?.copyWith(
                  fontSize: 20,
                  fontWeight: FontWeight.w800,
                  color: AppColors.primary,
                ),
              ),
              Text(
                streak == 1 ? 'يوم متواصل' : 'أيام متواصلة',
                style: theme.textTheme.bodySmall?.copyWith(fontSize: 11),
              ),
            ],
          ),
          const Spacer(),
          Row(
            children: [
              for (final d in last7)
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 3),
                  child: Column(
                    children: [
                      Container(
                        width: d.isToday ? 15 : 11,
                        height: d.isToday ? 15 : 11,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: d.active
                              ? AppColors.success
                              : (d.isToday
                                  ? AppColors.warning
                                  : AppColors.line),
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        d.name,
                        style: theme.textTheme.labelSmall?.copyWith(
                          fontSize: 9.5,
                          color: d.isToday
                              ? AppColors.primary
                              : AppColors.textFaint,
                          fontWeight:
                              d.isToday ? FontWeight.w700 : FontWeight.w400,
                        ),
                      ),
                    ],
                  ),
                ),
            ],
          ),
        ],
      ),
    );
  }
}
