import 'package:flutter_test/flutter_test.dart';
import 'package:rafiq_al_quran/models/app_state.dart';

void main() {
  group('AppState — الحالة الافتراضية', () {
    test('يبدأ بقيم defaults() مطابقة للنسخة الأصلية', () {
      final state = AppState.defaults();
      expect(state.v, 1);
      expect(state.profile.name, '');
      expect(state.profile.avatar, 'falcon');
      expect(state.profile.onboarded, false);
      expect(state.settings.reciter, 'Minshawy_Murattal_128kbps');
      expect(state.settings.memorizationDirection, 'backward');
      expect(state.progress, isEmpty);
      expect(state.rewards.stars, 0);
      expect(state.rewards.points, 0);
      expect(state.lastAyah.s, 112);
      expect(state.lastAyah.a, 1);
    });
  });

  group('AppState — التحليل الآمن من JSON', () {
    test('roundtrip كامل: toJson ثم fromJson يحفظ كل الحقول', () {
      final state = AppState.defaults().copyWith(
        profile: const AppProfile(name: 'أحمد', avatar: 'lion'),
        rewards: const RewardsState(stars: 12, points: 260, badges: ['ayahs_5']),
        stats: const StatsState(
          activeDays: ['2026-10-20', '2026-10-21', '2026-10-22'],
          reviewsDone: 3,
        ),
        progress: {
          '112': const SurahProgress(
            status: 'mastered',
            memorized: [1, 2, 3],
            mastery: 100,
          ),
          '113': const SurahProgress(
            status: 'learning',
            memorized: [1],
            mastery: 20,
          ),
        },
        lastAyah: const LastAyah(s: 113, a: 4),
      );

      final decoded = AppState.fromJsonString(state.toJsonString());

      expect(decoded.profile.name, 'أحمد');
      expect(decoded.profile.avatar, 'lion');
      expect(decoded.rewards.stars, 12);
      expect(decoded.rewards.points, 260);
      expect(decoded.rewards.badges, ['ayahs_5']);
      expect(decoded.progress['112']?.memorized, [1, 2, 3]);
      expect(decoded.progress['112']?.isMastered, isTrue);
      expect(decoded.progress['113']?.memorized.length, 1);
      expect(decoded.lastAyah.s, 113);
      expect(decoded.lastAyah.a, 4);
    });

    test('JSON فاسد تمامًا يعيد الحالة الافتراضية بدل انهيار التطبيق', () {
      final state = AppState.fromJsonString('{not valid json at all');
      expect(state.progress, isEmpty);
      expect(state.rewards.stars, 0);
    });

    test('حقول مفقودة تُدمج مع الافتراضيات (سلوك Object.assign الأصلي)', () {
      final state = AppState.fromJsonString(
        '{"v":1,"progress":{"114":{"status":"mastered","memorized":[1,2,3,4,5,6]}}}',
      );
      expect(state.progress['114']?.memorized.length, 6);
      // حقول لم ترد في JSON تبقى افتراضية
      expect(state.profile.name, '');
      expect(state.settings.autoPlay, true);
    });
  });

  group('المقاييس المشتقة — مطابقة لدول storage.js', () {
    test('memorizedAyahsCount يجمع آيات كل السور', () {
      final state = AppState.defaults().copyWith(
        progress: {
          '112': const SurahProgress(memorized: [1, 2, 3]),
          '113': const SurahProgress(memorized: [1, 2]),
        },
      );
      expect(state.memorizedAyahsCount, 5);
    });

    test('masteredSurahsCount و inProgressSurahsCount يفرّقان الحالات', () {
      final state = AppState.defaults().copyWith(
        progress: {
          '112': const SurahProgress(status: 'mastered', memorized: [1]),
          '113': const SurahProgress(status: 'learning', memorized: [1, 2]),
          '114': const SurahProgress(status: 'learning', memorized: []),
        },
      );
      expect(state.masteredSurahsCount, 1);
      expect(state.inProgressSurahsCount, 1);
    });
  });

  group('computeStreak — سلسلة الأيام المتواصلة', () {
    test('بدون أيام نشطة → صفر', () {
      expect(computeStreak(const [], DateTime(2026, 10, 23)), 0);
    });

    test('أيام متتالية حتى اليوم تُحسب كلها', () {
      final streak = computeStreak(
        ['2026-10-20', '2026-10-21', '2026-10-22', '2026-10-23'],
        DateTime(2026, 10, 23),
      );
      expect(streak, 4);
    });

    test('آخر يوم نشط هو أمس تستمر السلسلة (لم يُسجل اليوم بعد)', () {
      final streak = computeStreak(
        ['2026-10-21', '2026-10-22'],
        DateTime(2026, 10, 23),
      );
      expect(streak, 2);
    });

    test('انقطاع يومين يُصفّر السلسلة', () {
      final streak = computeStreak(
        ['2026-10-19', '2026-10-20'],
        DateTime(2026, 10, 23),
      );
      expect(streak, 0);
    });

    test('يوم واحد سابق يُعطى 1', () {
      expect(
        computeStreak(['2026-10-22'], DateTime(2026, 10, 23)),
        1,
      );
    });
  });

  group('levelInfoFor — عتبات المستويات من rewards.js', () {
    test('صفر نقاط → المستوى 1', () {
      final info = levelInfoFor(0);
      expect(info.level, 1);
      expect(info.title, 'مبتدئ مجتهد');
      expect(info.next?.minPoints, 100);
    });

    test('100 نقطة → المستوى 2', () {
      expect(levelInfoFor(100).level, 2);
      expect(levelInfoFor(100).title, 'صاعد نحو الخير');
    });

    test('1000 نقطة → المستوى 6: حافظ صغير', () {
      final info = levelInfoFor(1000);
      expect(info.level, 6);
      expect(info.title, 'حافظ صغير');
    });

    test('1400+ نقطة → المستوى الأقصى 7 بدون تقدم زائد', () {
      final info = levelInfoFor(5000);
      expect(info.level, 7);
      expect(info.title, 'قائد الأبطال');
      expect(info.next, isNull);
      expect(info.progressPercent, 100);
    });

    test('التقدم داخل المستوى يُحسب صحيحًا', () {
      // بين 100 و 250: المدى 150، و عند 175 → (75/150)=50%
      final info = levelInfoFor(175);
      expect(info.level, 2);
      expect(info.progressPercent, 50);
    });
  });
}
