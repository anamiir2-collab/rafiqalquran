import 'package:flutter_test/flutter_test.dart';
import 'package:rafiq_al_quran/core/utils/arabic_digits.dart';
import 'package:rafiq_al_quran/core/constants/app_constants.dart';

void main() {
  group('toArabicDigits', () {
    test('يحوّل الأرقام اللاتينية إلى عربية', () {
      expect(toArabicDigits('123'), '١٢٣');
      expect(toArabicDigits('0'), '٠');
    });

    test('يُبقي النص العربي كما هو ويحوّل الأرقام وسطه', () {
      expect(toArabicDigits('سورة 112'), 'سورة ١١٢');
      expect(toArabicDigits('المستوى 7: حافظ صغير'), 'المستوى ٧: حافظ صغير');
    });

    test('نص بدون أرقام يبقى دون تغيير', () {
      expect(toArabicDigits('رحلتك اليوم'), 'رحلتك اليوم');
    });
  });

  group('arNum', () {
    test('ينسّق عددًا صحيحًا بالأرقام العربية', () {
      expect(arNum(0), '٠');
      expect(arNum(564), '٥٦٤');
    });

    test('فصل الآلاف بفاصلة عربية عند الطلب', () {
      expect(arNum(6236, groupThousands: true), '٦،٢٣٦');
    });
  });

  group('AppConstants — نمط رابط الصوت everyayah', () {
    test('يولّد رابطًا صحيحًا بثلاث خانات للسورة والآية', () {
      final url = AppConstants.ayahAudioUrl(
        'Minshawy_Murattal_128kbps',
        112,
        1,
      );
      expect(
        url,
        'https://everyayah.com/data/Minshawy_Murattal_128kbps/112001.mp3',
      );
    });

    test('السور ثلاثية الأرقام تمر كما هي', () {
      final url = AppConstants.ayahAudioUrl('Alafasy_128kbps', 114, 6);
      expect(url, 'https://everyayah.com/data/Alafasy_128kbps/114006.mp3');
    });
  });
}
