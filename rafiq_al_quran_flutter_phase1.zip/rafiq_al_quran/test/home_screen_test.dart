import 'package:flutter_test/flutter_test.dart';
import 'package:rafiq_al_quran/app.dart';
import 'package:rafiq_al_quran/providers/progress_provider.dart';
import 'package:rafiq_al_quran/providers/user_provider.dart';
import 'package:rafiq_al_quran/services/storage_service.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  Future<void> pumpHome(WidgetTester tester) async {
    SharedPreferences.setMockInitialValues({});
    final storage = StorageService();
    await storage.load();
    await tester.pumpWidget(
      MultiProvider(
        providers: [
          Provider<StorageService>.value(value: storage),
          ChangeNotifierProvider<UserProvider>(
            create: (_) => UserProvider(storage),
          ),
          ChangeNotifierProvider<ProgressProvider>(
            create: (_) => ProgressProvider(storage),
          ),
        ],
        child: const RafiqApp(),
      ),
    );
    await tester.pumpAndSettle();
  }

  group('HomeScreen — المرحلة الأولى', () {
    testWidgets('تظهر التحية العامة عندما لا يوجد اسم محفوظ', (tester) async {
      await pumpHome(tester);
      expect(find.text('السلام عليكم يا بطل'), findsOneWidget);
    });

    testWidgets('بطاقة رحلتك اليوم ظاهرة', (tester) async {
      await pumpHome(tester);
      expect(find.text('رحلتك اليوم'), findsOneWidget);
      expect(find.text('ابدأ رحلتي'), findsOneWidget);
    });

    testWidgets('العدادات تبدأ بأصفار حقيقية — بلا بيانات وهمية',
        (tester) async {
      await pumpHome(tester);
      // أربع قيم صفرية: النجوم + الآيات + السور + سلسلة الأيام
      expect(find.text('٠'), findsWidgets);
      expect(find.text('نجمة'), findsOneWidget);
      expect(find.text('آية محفوظة'), findsOneWidget);
      expect(find.text('سورة قيد التقدم'), findsOneWidget);
    });

    testWidgets('اختصارات الأقسام الثمانية ظاهرة', (tester) async {
      await pumpHome(tester);
      expect(find.text('مدينة القرآن'), findsOneWidget);
      expect(find.text('رحلة الحفظ'), findsOneWidget);
      expect(find.text('وادي المراجعة'), findsOneWidget);
      expect(find.text('واحة القصص'), findsOneWidget);
      expect(find.text('حديقة الأخلاق'), findsOneWidget);
      expect(find.text('تحديات الإتقان'), findsOneWidget);
      expect(find.text('المكافآت'), findsOneWidget);
      expect(find.text('لوحة ولي الأمر'), findsOneWidget);
    });

    testWidgets('حفظ الاسم يُحدّث التحية فورًا', (tester) async {
      await pumpHome(tester);

      // افتح حوار الاسم — pump يدوي لأن مؤشر الكتابة الوامض
      // لا يسمح بـ pumpAndSettle داخل الحوار
      await tester.tap(find.byIcon(Icons.tune_rounded));
      await tester.pump();
      await tester.pump(const Duration(milliseconds: 300));

      await tester.enterText(find.byType(TextField), 'يوسف');
      await tester.tap(find.text('حفظ'));
      await tester.pumpAndSettle();

      expect(find.text('السلام عليكم يا يوسف'), findsOneWidget);
    });

    testWidgets('ضغط اختصار غير منفذ يُظهر رسالة صادقة — لا انهيار',
        (tester) async {
      await pumpHome(tester);

      await tester.tap(find.text('مدينة القرآن'));
      await tester.pump();

      expect(find.textContaining('المرحلة ٣'), findsOneWidget);
    });
  });
}
