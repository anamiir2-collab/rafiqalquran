import 'package:flutter_test/flutter_test.dart';
import 'package:rafiq_al_quran/models/app_state.dart';
import 'package:rafiq_al_quran/services/storage_service.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  setUp(() {
    // تخزين وهمي فارغ لكل اختبار
    SharedPreferences.setMockInitialValues({});
  });

  group('StorageService — التحميل الأول', () {
    test('أول تشغيل (بدون بيانات محفوظة) يعيد الحالة الافتراضية', () async {
      final storage = StorageService();
      final state = await storage.load();

      expect(state.v, 1);
      expect(state.profile.name, '');
      expect(state.rewards.stars, 0);
      expect(state.progress, isEmpty);
    });
  });

  group('StorageService — الحفظ والاستعادة', () {
    test('الاسم المحفوظ يعود بعد إعادة التشغيل (استعادة التقدم)', () async {
      final storage1 = StorageService();
      await storage1.load();
      await storage1.updateProfile(
        storage1.state.profile.copyWith(name: 'مريم'),
      );
      await storage1.setLastAyah(108, 3);

      // محاكاة إغلاق التطبيق وفتحه من جديد بمثيل جديد
      final storage2 = StorageService();
      final reloaded = await storage2.load();

      expect(reloaded.profile.name, 'مريم');
      expect(reloaded.lastAyah.s, 108);
      expect(reloaded.lastAyah.a, 3);
    });

    test('تقدم السور يُحفظ ويُستعاد بالكامل', () async {
      final storage1 = StorageService();
      await storage1.load();
      final updated = storage1.state.copyWith(
        progress: {
          '112': const SurahProgress(
            status: 'mastered',
            memorized: [1, 2, 3, 4],
            mastery: 100,
            reviewCount: 2,
          ),
        },
        rewards: const RewardsState(stars: 5, points: 120),
      );
      await storage1.save(updated);

      final storage2 = StorageService();
      final reloaded = await storage2.load();

      expect(reloaded.progress['112']?.memorized, [1, 2, 3, 4]);
      expect(reloaded.progress['112']?.isMastered, isTrue);
      expect(reloaded.rewards.stars, 5);
      expect(reloaded.rewards.points, 120);
    });

    test('البيانات الفاسدة في التخزين لا تُسقط التطبيق', () async {
      SharedPreferences.setMockInitialValues({
        'rafiq_state_v1': '}}}corrupted{{{',
      });

      final storage = StorageService();
      final state = await storage.load();

      expect(state.v, 1);
      expect(state.progress, isEmpty);
    });
  });

  group('StorageService — إعادة التعيين', () {
    test('reset يعيد كل شيء للقيم الافتراضية', () async {
      final storage = StorageService();
      await storage.load();
      await storage.updateProfile(
        storage.state.profile.copyWith(name: 'سالم'),
      );

      await storage.reset();

      expect(storage.state.profile.name, '');
      expect(storage.state.rewards.stars, 0);

      // ويُمسح من التخزين فعلًا
      final fresh = StorageService();
      final reloaded = await fresh.load();
      expect(reloaded.profile.name, '');
    });
  });
}
